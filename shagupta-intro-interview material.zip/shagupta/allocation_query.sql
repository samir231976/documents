create table ProcessKittedQuantityTableCte as
SELECT
    t1.id,t1.project_id, t1.bom_id,t1.module_number,t1.station_id,
    MIN(t1.received_quantity) AS received_quantity,
    LEAST(
        MIN(t1.received_quantity),
        COALESCE(MIN(t2.quantity_kitted_allocated), 0) - COALESCE(LEAST(SUM(t1p.received_quantity - t1p.kitted_quantity), MIN(t2.quantity_kitted_allocated)), 0) + MIN(t1.kitted_quantity)
    ) AS kitted_quantity,
    t1.SORTED
FROM
    kittedallocationstationmaster t1
LEFT JOIN
    new_mboa_module_uin_details t2 ON t2.project_id = t1.project_id
    AND t2.module_number = t1.module_number
    AND t2.bom_id = t1.bom_id
LEFT JOIN
    kittedallocationstationmaster t1p ON t1p.project_id = t1.project_id
    AND t1p.module_number = t1.module_number
    AND t1p.bom_id = t1.bom_id
    AND t1p.SORTED < t1.SORTED
GROUP BY
    t1.ID,
    t1.project_id,
    t1.bom_id,
    t1.module_number,
    t1.SORTED
ORDER BY
    t1.project_id,
    t1.bom_id,
    t1.module_number,
    t1.SORTED;

