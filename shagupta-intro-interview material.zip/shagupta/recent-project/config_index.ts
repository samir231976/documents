/**
 * =============================================================================
 * @file The service configuration file.
 * @desc This file provides a means to customize and configure the capabilities
 * and functionality of the service.
 * =============================================================================
 */


// Import the dependencies.
import type { IConfig } from '#interfaces';


/**
 * -----------------------------------------------------------------------------
 * See README.md for information about configuration options.
 * -----------------------------------------------------------------------------
 */
const config: IConfig = {
	catalogs: {
		rateplans: {
			auth: {
				headers: {
					application: process.env.PROJECT_NAME,
					consumerType: 'EventBased',
				},
				method: 'POST',
				tokenName: 'rateplanBearerToken',
			},
			events: {
				RateplanChangeActivated: {
					getEventData: event => {
						return {
							eventName: event.eventType,
							entityId: +event.payload.changeEvent.enterpriseId,
						};
					},
					getResourceUri: data => {
						return `/products/v3/rateplans?rateplanSpecId=${data.entityId}`;
					},
					isAssociated: event => {
						return event.eventProducerId === 'MasterProductManagement'
							&& event.eventType === 'RateplanChangeActivated';
					},
				},
				RateplanOfferChangeActivated: {
					getEventData: event => {
						return {
							eventName: event.eventType,
							entityId: +event.payload.changeEvent.enterpriseId,
							compType: 'offer',
						};
					},
					getResourceUri: data => `/products/v3/rateplans?rateplanOfferId=${data.id}`,
					isAssociated: event => {
						return event.eventProducerId === 'MasterProductManagement'
							&& event.eventType === 'RateplanOfferChangeActivated';
					}
				},
			},
			resource: {
				composite: {
					offer: {
						getCompEntityById: {
							method: 'GET',
							uri(data) {
								return `/products/v3/rateplans?rateplanOfferId=${data.compEntityId}`;
							},
						},
						getCoreEntityIdsFromSourceResponse(sourceResponse) {
							return sourceResponse.data
								.rateplanSpecs
								.map(rateplanSpec => {
									return rateplanSpec.identifier
										.ratePlanSpecId;
								});
						},
					},
				},
				core: {
					getCoreEntitiesByBatch: {
						maxEntitiesPerCall: 100,
						method: 'GET',
						uri(data) {
							return `/products/v3/rateplans?filter=excludeofferless&start=${data.offset}&limit=${data.limit}`;
						},
					},
					getCoreEntitiesByList: {
						maxEntitiesPerCall: 25,
						method: 'GET',
						uri(data) {
							return `/products/v3/rateplans?filter=excludeofferless&rateplanSpecId=${data.coreEntityIds}`;
						},
					},
					getEntitiesFromBatchSourceResponse(sourceResponse) {
						return sourceResponse.data.rateplanSpecs;
					},
					getEntitiesFromListSourceResponse(sourceResponse) {
						return sourceResponse.data.rateplanSpecs;
					},
					getIdFromSourceEntity(sourceEntity) {
						return sourceEntity.identifier.ratePlanSpecId;
					}
				},
			},
			trimNodePaths: [
				'customerFacingServices',
				'description',
				'lastUpdatedTime',
				'longDescription',
				'longName',
				'name',
				'rateplanOffers[].additionalLines',
				'rateplanOffers[].associatedDeviceTreatment',
				'rateplanOffers[].availability.marketGroups',
				'rateplanOffers[].availability.markets',
				'rateplanOffers[].compatibleDeviceVariants',
				'rateplanOffers[].compatibleServices',
				'rateplanOffers[].creditCheckRequired',
				'rateplanOffers[].deviceVariantCompatibility',
				'rateplanOffers[].includedLines',
				'rateplanOffers[].isPromotional',
				'rateplanOffers[].lastUpdatedTime',
				'rateplanOffers[].pricePoint.meteredCharges',
				'rateplanOffers[].pricePoint.recurringCharges[].code',
				'rateplanOffers[].pricePoint.recurringCharges[].description',
				'rateplanOffers[].pricePoint.recurringCharges[].initiationOccurrence',
				'rateplanOffers[].pricePoint.recurringCharges[].name',
				'rateplanOffers[].pricePoint.recurringCharges[].occurenceCount',
				'rateplanOffers[].requiredServices[].description',
				'rateplanOffers[].requiredServices[].maximum',
				'rateplanOffers[].requiredServices[].minimum',
				'rateplanOffers[].sortOrder',
				'shortName',
				'voiceTextAllowances',
			],
			booleanNodePaths: [
				'renewable',
				'rateplanOffers[].SamsonBilling.isPooledPlan',
				'rateplanOffers[].SamsonBilling.hybridBanEligible',
				'rateplanOffers[].pricePoint.serviceTaxIncluded',
			]
		},
		services: {
			auth: {
				headers: {
					application: process.env.PROJECT_NAME,
					consumerType: 'EventBased',
				},
				method: 'POST',
				tokenName: 'serviceBearerToken',
			},
			events: {
				ServiceChangeActivated: {
					getEventData: event => {
						return {
							eventName: event.eventType,
							entityId: +event.payload.changeEvent.enterpriseId,
						};
					},
					getResourceUri: data => {
						return `/products/v3/services?serviceSpecId=${data.entityId}`;
					},
					isAssociated: event => {
						return event.eventProducerId === 'MasterProductManagement'
							&& event.eventType === 'ServiceChangeActivated';
					},
				},
				ServiceOfferChangeActivated: {
					getEventData: event => {
						return {
							eventName: event.eventType,
							entityId: +event.payload.changeEvent.enterpriseId,
							compType: 'offer',
						};
					},
					getResourceUri: data => `/products/v3/services?serviceOfferId=${data.id}`,
					isAssociated: event => {
						return event.eventProducerId === 'MasterProductManagement'
							&& event.eventType === 'ServiceOfferChangeActivated';
					}
				},
			},
			resource: {
				composite: {
					offer: {
						getCompEntityById: {
							method: 'GET',
							uri(data) {
								return `/products/v3/services?serviceOfferId=${data.compEntityId}`;
							},
						},
						getCoreEntityIdsFromSourceResponse(sourceResponse) {
							return sourceResponse.data
								.serviceSpecs
								.map(serviceModelSpecs => {
									return serviceModelSpecs.identifier
										.serviceSpecId;
								});
						},
					},
				},
				core: {
					getCoreEntitiesByBatch: {
						maxEntitiesPerCall: 100,
						method: 'GET',
						uri(data) {
							return `/products/v3/services?filter=excludeofferless&start=${data.offset}&limit=${data.limit}`;
						},
					},
					getCoreEntitiesByList: {
						maxEntitiesPerCall: 25,
						method: 'GET',
						uri(data) {
							return `/products/v3/services?filter=excludeofferless&serviceSpecId=${data.coreEntityIds}`;
						},
					},
					getEntitiesFromBatchSourceResponse(sourceResponse) {
						console.log("total MPM Count ######", sourceResponse.data?.totalResultCount);
						return sourceResponse.data.serviceSpecs;
					},
					getEntitiesFromListSourceResponse(sourceResponse) {
						return sourceResponse.data.serviceSpecs;
					},
					getIdFromSourceEntity(sourceEntity) {
						return sourceEntity.identifier.serviceSpecId;
					}
				},
			},
			trimNodePaths: [
				'serviceOffers[].compatibleRatePlanOffers',
				'serviceOffers[].conflictingServiceOffers',
				'serviceOffers[].prerequisiteServiceOffers',
				'serviceOffers[].dependentServicesServiceOffers',
				'serviceOffers[].compatibleDeviceVariants',
				'serviceOffers[].availability.marketGroups',
				'serviceOffers[].availability.markets',
				'serviceOffers[].availability.stateCodes',
				'serviceOffers[].eligibility.accounts',
				'serviceOffers[].creditCheckRequired',
				'serviceOffers[].isPromotional',
				'serviceOffers[].duration',
				'serviceOffers[].durationUom',
				'serviceOffers[].removableBy',
				'serviceOffers[].prerequisiteOfferType',
				'serviceOffers[].visibility',
				'serviceOffers[].lastUpdatedTime',
				'serviceOffers[].sortOrder',
				'sortOrder',
				'lastUpdatedTime'
			],
			booleanNodePaths: [
				'isNotOfferedOnDevice',
				'serviceOffers[].isDeviceIndependent',
				'serviceOffers[].pricePoint.serviceTaxIncluded',
			]
		},
		devices: {
			auth: {
				headers: {
					application: process.env.PROJECT_NAME,
					consumerType: 'EventBased',
				},
				method: 'POST',
				tokenName: 'deviceBearerToken',
			},
			events: {
				DeviceModelChangeActivated: {
					getEventData: event => {
						return {
							eventName: event.eventType,
							entityId: +event.payload.changeEvent.enterpriseId,
						};
					},
					getResourceUri: data => {
						return `/products/v3/devices?deviceModelSpecId=${data.entityId}`;
					},
					isAssociated: event => {
						return event.eventProducerId === 'MasterProductManagement'
							&& event.eventType === 'DeviceModelChangeActivated';
					},
				},
				DeviceOfferChangeActivated: {
					getEventData: event => {
						return {
							eventName: event.eventType,
							entityId: +event.payload.changeEvent.enterpriseId,
							compType: 'offer',
						};
					},
					getResourceUri: data => `/products/v3/devices?deviceOfferId=${data.id}`,
					isAssociated: event => {
						return event.eventProducerId === 'MasterProductManagement'
							&& event.eventType === 'DeviceOfferChangeActivated';
					}
				},
				DeviceVariantChangeActivated: {
					getEventData: event => {
						return {
							eventName: event.eventType,
							entityId: +event.payload.changeEvent.enterpriseId,
							compType: 'variant',
						};
					},
					getResourceUri: data => `/products/v3/devices?deviceVariantSpecId=${data.id}`,
					isAssociated: event => {
						return event.eventProducerId === 'MasterProductManagement'
							&& event.eventType === 'DeviceVariantChangeActivated';
					}
				},
			},
			resource: {
				composite: {
					offer: {
						getCompEntityById: {
							method: 'GET',
							uri(data) {
								return `/products/v3/devices?deviceOfferId=${data.compEntityId}`;
							},
						},
						getCoreEntityIdsFromSourceResponse(sourceResponse) {
							return sourceResponse.data
								.deviceModelSpecs
								.map(deviceModelSpecs => {
									return deviceModelSpecs.identifier
										.deviceModelSpecId;
								});
						},
					},
					variant: {
						getCompEntityById: {
							method: 'GET',
							uri(data) {
								return `/products/v3/devices?deviceVariantSpecId=${data.compEntityId}`;
							},
						},
						getCoreEntityIdsFromSourceResponse(sourceResponse) {
							return sourceResponse.data
								.deviceModelSpecs
								.map(deviceModelSpecs => {
									return deviceModelSpecs.identifier
										.deviceModelSpecId;
								});
						},
					},
				},
				core: {
					getCoreEntitiesByBatch: {
						maxEntitiesPerCall: 500,
						method: 'GET',
						uri(data) {
							return `/products/v3/devices?filter=excludeofferless&start=${data.offset}&limit=${data.limit}`;
						},
					},
					getCoreEntitiesByList: {
						maxEntitiesPerCall: 25,
						method: 'GET',
						uri(data) {
							return `/products/v3/devices?filter=excludeofferless&deviceModelSpecId=${data.coreEntityIds}`;
						},
					},
					getEntitiesFromBatchSourceResponse(sourceResponse) {
						return sourceResponse.data.deviceModelSpecs;
					},
					getEntitiesFromListSourceResponse(sourceResponse) {
						return sourceResponse.data.deviceModelSpecs;
					},
					getIdFromSourceEntity(sourceEntity) {
						return sourceEntity.identifier.deviceModelSpecId;
					}
				},
			},
			trimNodePaths: [
				'deviceVariantSpecs[].deviceOffers',
				'deviceVariantSpecs[].simPackaging',
				'deviceVariantSpecs[].sortOrder',
				'deviceVariantSpecs[].deviceTier',
				'deviceVariantSpecs[].compatibleRatePlans',
				'deviceVariantSpecs[].associatedFees',
				'deviceVariantSpecs[].compatibleServices',
				'deviceVariantSpecs[].lastUpdatedTime',
				'deviceVariantSpecs[].titleTag',
				'deviceVariantSpecs[].altTag',
				'deviceVariantSpecs[].metaTag',
				'deviceVariantSpecs[].h1Tag',
				'deviceVariantSpecs[].condition',
				'deviceVariantSpecs[].itemCost',
				'deviceVariantSpecs[].boxContents',
				'deviceVariantSpecs[].warrantyDurationUom',
				'deviceVariantSpecs[].outOfStockThreshold',
				'deviceVariantSpecs[].limitedQuantityThreshold',
				'deviceVariantSpecs[].characteristics',
				'deviceVariantSpecs[].deductibleAmounts',
				'deviceVariantSpecs[].isByod',
				'deviceVariantSpecs[].aStockDevice',
				'deviceVariantSpecs[].preOwnedDevice',
				'channelVariances',
				'associatedProducts',
				'simPackaging',
				'compatibleAccessoryModels',
				'variantDifferentiators',
				'lastUpdatedTime',
				'supportedCustomerFacingServices',
				'shapes'
			],
			booleanNodePaths: [
				'deviceVariantSpecs[].isDefaultVariant',
				'deviceVariantSpecs[].limitedTimeUsage',
			]
		},
	},
	maxFailedSyncEntities: 5,
	maxSuccessfulSyncEntities: Infinity,
	middlewares: {
		timer: {
			localsVarName: 'startDatetime',
		},
	},
	packages: {
		objectMergeAdvanced: {
			dedupeStringsInArrayValues: true,
		},
	},
	secretsEnvVarIds: [
		'clientId',
		'clientSecret',
		'privateKey',
	],
	secretsPrefix: 'ENV_SECRET_CATALOG_CACHE_SYNC_'
}


// Export the interface.
export default config;
