/**
 * =============================================================================
 * @file The `catalog` controller.
 * @desc This file providers controller logic for `catalog` entities and
 * related functionality.
 * =============================================================================
 */


// Import the dependencies.
import type { ICatalog } from '#interfaces';
import {
	BadRequestException,
	HttpException,
	HttpStatus,
	NotFoundException,
	InternalServerErrorException,
} from '@nestjs/common';
import AwsOpenSearchService from '#providers/aws/opensearch.service';
import TmusAuthenticationService from '#providers/tmus/authentication.service';
import config from '#config';
import process from 'node:process';
import { trimEntityBody } from '#libs/transform.lib';
import { LoggerUtil, LogEvent, ILogKeys } from '../Entity/logger';
import { mergeCustomAttribute } from '#libs/merge.lib';



const authService = TmusAuthenticationService.getInstance();
const dataService = AwsOpenSearchService.getInstance();
const {
	maxFailedSyncEntities: MAX_FAILED_SYNC_ENTITIES,
	maxSuccessfulSyncEntities: MAX_SUCCESSFUL_SYNC_ENTITIES,
	packages: {
		objectMergeAdvanced: mergeOptions,
	},
} = config;


/**
 * -----------------------------------------------------------------------------
 * The Catalog class.
 * -----------------------------------------------------------------------------
 */
class Catalog implements ICatalog {
	public readonly name;

	/**
	 * ---------------------------------------------------------------------------
	 * Creates an instance of a Catalog.
	 * ---------------------------------------------------------------------------
	 * @param name - The name of the catalog.
	 * @returns    - A new Catalog instance.
	 * ---------------------------------------------------------------------------
	 */
	constructor(name: string) {
		if (!(Object.keys(config.catalogs).includes(name))) {
			throw new Error(`Catalog: '${name}' is not supported`);
		}

		this.name = name;
	}


	/**
	 * ---------------------------------------------------------------------------
	 * Returns a reference to the Catalog's configuration.
	 * ---------------------------------------------------------------------------
	 */
	get config() {
		return config.catalogs[this.name];
	}


	/**
	 * ---------------------------------------------------------------------------
	 * Returns requested environment variables for the document's catalog.
	 * ---------------------------------------------------------------------------
	 * @param varIds - An array of environment variable category keys.
	 * @returns      - An array of respective environment variable category key
	 *                 values for the document's catalog, pulled from the
	 *                 process.env
	 * ---------------------------------------------------------------------------
	 */
	getEnvVars(varIds: string[]): (string | number | boolean | undefined)[] {
		try {
			const context = this;

			// Iterate through all environment variables provided.
			return varIds.map(varId => {
				const isVarSecret = config.secretsEnvVarIds.includes(varId);

				let varKey = `CATALOG_${context.name}`;

				// Append on the respective string based on the var key.
				switch (varId) {
					case 'authRequestUri':
						varKey += `_AUTH_REQUEST_URI`;
						break;
					case 'clientId':
						varKey += `_CLIENT_ID`;
						break;
					case 'clientSecret':
						varKey += `_CLIENT_SECRET`;
						break;
					case 'host':
						varKey += `_HOST`;
						break;
					case 'privateKey':
						varKey += `_PRIVATE_KEY`;
						break;
					case 'syncFailThreshold':
						varKey += '_SYNC_FAILURE_THRESHOLD';
						break;
					case 'syncPageSize':
						varKey += '_SYNC_PAGE_SIZE';
						break;
					case 'authHost':
						varKey += `_AUTH_HOST`;
						break;
					case 'searchIndex':
						varKey += '_SEARCH_INDEX';
						break;
					case 'storeIndex':
						varKey += '_STORE_INDEX';
						break;
					default:
						throw new InternalServerErrorException(
							`The environment variable key: '${varId}' is not supported`
						);
				}

				// If the var is a secret, prepend the secrets prefix.
				isVarSecret && (varKey = `${config.secretsPrefix}${varKey}`);

				let varValue = process.env[varKey.toUpperCase()];

				// Return as undefined.
				if (!varValue) {
					return;
				}

				// Return as boolean.
				{
					const varValueToLower = varValue.toLowerCase();

					if (varValueToLower === 'true' || varValueToLower === 'false') {
						return Boolean(varKey);
					}
				}

				// Return as numeric.
				if (!isNaN(Number(varValue))) {
					return +varValue;
				}

				// Return as literal string.
				return varValue;
			});
		} catch (error) {
			throw new InternalServerErrorException(
				`An error occurred while retrieving environment variables for the '${this.name}' catalog.`,
				{ cause: error },
			);
		}
	}
}


/**
 * -----------------------------------------------------------------------------
 * Iterates over an event request payload, testing each catalog's event
 * association logic, and extracting data from it. All keys in the returned
 * result should contain non-null/undefined values. The presence of either a
 * null/undefined value (as well the determination that no catalog is associated
 * with the eventRequest) will throw an error.
 * -----------------------------------------------------------------------------
 */
function getDataFromEventRequest(eventRequest: Record<string, any>): Record<string, any> {
	try {
		let result: Record<string, any>;

		// Iterate through each catalog to determine its association with the event.
		for (const catalogName of Object.keys(config.catalogs)) {
			const catalogConfig = config.catalogs[catalogName];

			// Iterate through each event the current catalog is subscribed to.
			for (const eventName of Object.keys(catalogConfig.events)) {
				if (catalogConfig.events[eventName].isAssociated(eventRequest)) {
					result = catalogConfig.events[eventName].getEventData(eventRequest);
					result.catalogName = catalogName;

					// Ensure each key in the returned result contains a non-null/
					// undefined value prior to returning.
					for (const [key, value] of Object.entries(result)) {
						if (value === null || value === undefined) {
							throw `While extracting data from event request, key: '${key}' `
							+ `contains an unsupported value: ${value}`;
						}
					}

					return result;
				}
			}
		}

		throw `The event request payload could not be associated with a supported catalog`;
	} catch (error) {
		if (typeof error === 'string') {
			throw new BadRequestException(error);
		} else {
			throw new InternalServerErrorException(
				`An error occurred while extracting data from the event request.`,
				{ cause: error },
			);
		}
	}
}


/**
 * -----------------------------------------------------------------------------
 * Abstracts the logic necessary to synchorize 1 or more core catalog entities
 * with the data store.
 * -----------------------------------------------------------------------------
 */
async function syncCatalogEntities(
	catalog: ICatalog,
	entityIds: number[],
	logger: LoggerUtil,
	logObj: ILogKeys,
	batchOptions?: { limit?: number; offset?: number; },
) {
	try {
		logObj.attachment = { catalog, entityIds, batchOptions }
		logger.info(LogEvent.serviceRequest, logObj);
		const failedEntities: Record<string, any>[] = [];
		const searchIndex = catalog.getEnvVars(['searchIndex'])[0] as string
		const storeIndex = catalog.getEnvVars(['storeIndex'])[0] as string
		const successfulEntities: Record<string, any>[] = [];
		const resourceType = entityIds.length
			? 'getCoreEntitiesByList' :
			'getCoreEntitiesByBatch';
		let { maxEntitiesPerCall } = catalog.config
			.resource
			.core[resourceType];
		const processMap = {};
		const batchProcessingOpts = { limit: maxEntitiesPerCall, offset: 1 };

		let message = 'All catalog synchronization operations were completed successfully';
		let continueProcessing = true;
		let requestIteration = 0;
		let resourceOpts = {};
		let entitiesToProcess = [];
		let currentEntityIds: number[] = [];

		if (batchOptions) {
			batchProcessingOpts.limit = batchOptions.limit && (batchOptions.limit > maxEntitiesPerCall)
				? maxEntitiesPerCall
				: Number(batchOptions.limit);
			batchProcessingOpts.offset = Number(batchOptions.offset) || 1;
		}

		while (continueProcessing) {
			requestIteration++;

			// In the event a list of entities is provided (this issue is not present
			// in batch processing, as each page returns entities that exist), we need
			// to update the process map to contain keys which match the ids
			// specified. This is to help track entities specified that don't exist in
			// the authoritative source, so that they can be properly identified as
			// 404 (failed) entities. For each request iteration, we need to populate
			// the process map with null values prior to making the call and then
			// placing each existing entity into the map. Lastly, a check for any
			// null values in the map will equate to entities which did not exist in
			// the authoritative source.
			if (entityIds.length) {
				// Determine the current entities to process based on the maximum
				// entities that the authoritative source can handle per request.
				currentEntityIds = entityIds.slice(
					((requestIteration - 1) * maxEntitiesPerCall),
					((requestIteration - 1) * maxEntitiesPerCall) + (maxEntitiesPerCall - 1)
				);

				// Populate each entity in the process map with a default null value.
				currentEntityIds.forEach(entityId => {
					processMap[entityId] = null;
				});

				resourceOpts = { coreEntityIds: currentEntityIds.join(',') };
			} else {
				resourceOpts = {
					limit: batchProcessingOpts.limit,
					offset: (requestIteration * batchProcessingOpts.limit)
						- (batchProcessingOpts.limit - batchProcessingOpts.offset),
				};
			}
			logObj.attachment = { catalog, resourceType, resourceOpts, message: 'Authenticating and retrieving catalog data from authoritative source' }
			logger.info(LogEvent.targetRequest, logObj);
			// Request the source data. For explicitly-defined entities, we generate a
			// comma-delimited list based on the current request iteration. For
			// implicitly-inferred entities, we merely generate the offset and limit
			// based on the request iteration and catalog configuration.
			const sourceResponse = await authService.getResource(
				catalog,
				resourceType,
				resourceOpts,
				logger,
				logObj
			);
			logObj.attachment = {  message: 'Source response retrieved' };
			logger.info(LogEvent.targetResponse, logObj);

			// Extract out the entities to process from the source response.
			// Hopefully, the response payload should be structured similarly whether
			// 1 or more entity ids are not found. This is to aide in the
			// determination afterwards whether a 404 should be thrown.
			entitiesToProcess = catalog.config
				.resource
				.core[
				entityIds.length
					? 'getEntitiesFromListSourceResponse'
					: 'getEntitiesFromBatchSourceResponse'
			](sourceResponse);

			// If a singular entity was requested, and the entities to process
			// returned back nothing, this is indicative that the entity does not
			// exist in the authoritative source and should result in a thrown error.
			if (entityIds.length === 1 && entitiesToProcess.length === 0) {
				throw new NotFoundException(
					`Catalog: '${catalog.name}', entity: '${entityIds[0]}' does not exist in the `
					+ `authoritative source`
				);
			}
			logObj.attachment = { message: "Synchronization with data store satrted" };
			logger.info(LogEvent.targetRequest, logObj);
			// Iterate through each extracted entity and synchronize with the data
			// store.
			const processedEntities = await Promise.all(
				entitiesToProcess.map(entity => {
					return new Promise(async (resolve, reject) => {
						try {
							// Capture the id from the entity and update the process map.
							const entityId = catalog.config
								.resource
								.core
								.getIdFromSourceEntity(entity);
							const entityKey = `${searchIndex}:${entityId}`;

							processMap[entityId] = entityId;

							// Trim the entity body.
							const trimmedSourceEntity = await trimEntityBody(entity, catalog.name);

							console.log(`Processing entity: '${entityKey}'`);

							// Retrieve the respective entities from the data store.
							const [
								storeDraftEntity,
								storePublishedEntity,
							] = await Promise.all([
								dataService.readDocumentById(storeIndex, `${entityKey}:draft`, logger, logObj),
								dataService.readDocumentById(storeIndex, `${entityKey}:published`, logger, logObj),
							]);

							// Determine if a draft version needs to forcibly be created. This
							// is true only if neither draft nor published versions exist.
							const forceCreateDraft = (!storeDraftEntity && !storePublishedEntity);

							// Merge the draft and published entities (if they exist) with the
							// trimmed source entity.
							const [
								mergedDraftEntity,
								mergedPublishedEntity,
							] = [
								storeDraftEntity,
								storePublishedEntity,
							].map(async (storeEntity, index) => {
								// If we're on the first iteration (draft) and no draft entity
								// exists in the data store and we're not forced to create a
								// draft entity (one exists), OR if we're not on the first
								// interation (published) and there is no published entity in the
								// data store, simply return a null construct, which will prevent
								// write operations for that respective store entity.
								if (
									(index === 0 && !storeEntity && !forceCreateDraft)
									|| (index !== 0 && !storeEntity)
								) {
									return null;
								}

								logObj.attachment = { message: "Custom merging started" }
								logger.info(LogEvent.targetRequest, logObj);
								// Used custom mergeFunction to merge object based on _souce field criteria
								const mergedEntity = mergeCustomAttribute(
									trimmedSourceEntity,
									storeEntity,
									mergeOptions,
								);
								logObj.attachment = { mergedEntity, message: 'Entity merged successfully' }
								logger.info(LogEvent.targetResponse, logObj);

								// Update the metadata of the merged entity prior to writing back
								// to the data store.
								updateEntityMetadata(
									mergedEntity as Record<string, any>,
									searchIndex,
									`${entityId}`,
									index ? 'published' : 'draft',
								)
								// Write the merged entity back to the data store.								
								let updatePromise: any;
								if ((index == 0 && (storeDraftEntity !== null || forceCreateDraft))) {
									updatePromise = dataService.updateDocument(
										storeIndex,
										`${entityKey}:draft`,
										mergedEntity,
										logger,
										logObj)

								} else if (storePublishedEntity !== null && index == 1) {
									updatePromise = dataService.updateDocument(
										storeIndex,
										`${entityKey}:published`,
										mergedEntity,
										logger,
										logObj
									)

								}
								if (updatePromise) {
									await updatePromise.then((val: any) => {
										if (val?.statusCode === 200 || val?.statusCode === 201) {
											resolve({
												datetime: new Date().toISOString(),
												draft_updated: mergedDraftEntity !== null,
												entity_id: entityId,
												published_updated: mergedPublishedEntity !== null,
											});
										}
									}).catch(err => {
										resolve({
											datetime: new Date().toISOString(),
											draft_updated: mergedDraftEntity !== null,
											entity_id: entityId,
											published_updated: mergedPublishedEntity !== null,
											error: err?.options?.cause?.meta?.body?.error
										});
									});
								} else {
									resolve({
										datetime: new Date().toISOString(),
										entity_id: entityId,
										error: 'An error occurred while processing entity'
									});

								}
								console.log(`Entity: '${entityKey}' processed successfully`);
								console.log(`Entity updated in store index ${storeIndex}`);
							});
						} catch (error) {
							// If an error occurs within the try, whether it be come the code
							// directly in it or awaited function calls that reject their
							// promise,
							console.error('Entity processing failed', error);
							logObj.attachment = { error, message: 'An error occurred while processing entity' };
							logger.error(LogEvent.targetResponse, logObj);
							reject({
								error: error.message || 'An error occurred while processing this entity',
							});
						}
					});
				})
			);
			logObj.attachment = { processedEntities, message: 'Entity processed after successfully synchronization' };
			logger.info(LogEvent.targetResponse, logObj);

			// Iterate over each entity id defined in the process map for the request
			// iteration and ensure that its value is not null. Null values indicate
			// that the entity was requested, but not found in the response, and
			// should be processed as a failed entity.
			currentEntityIds.forEach(entityId => {
				if (processMap[entityId] === null) {
					processedEntities.push(Promise.reject({
						error: `Entity id: '${entityId}' does not exist in authoriative source`
					}));
				}
			});

			// Process the responses of the entities processed for this request. This
			// updates the information which is returned from the synchronization
			// operation.
			processedEntities.forEach((entity: Record<string, any>) => {
				if ('error' in entity) {
					failedEntities.push(entity);
				} else {
					successfulEntities.push(entity);
				}
			});

			// Test for a multitude of reasons why processing should not continue.
			if (
				// Either the threshold of successful entities to sync has been met...
				(successfulEntities.length >= MAX_SUCCESSFUL_SYNC_ENTITIES)
				// ... or the threshold of failed entities to sync has been met...
				|| (failedEntities.length >= MAX_FAILED_SYNC_ENTITIES)
				// ...or the explicitly-defined response and its configured maximum
				// entities per call indicate no further requests are required...
				|| (entityIds.length && (requestIteration + 1) > Math.ceil(entityIds.length / maxEntitiesPerCall))
				// ...or the implicitly-inferred response contains less entities than
				// the maximum allowed per call, indicating it is at the end of its
				// entity pagination.
				|| (entityIds.length === 0 && processedEntities.length < batchProcessingOpts.limit)
			) {
				continueProcessing = false;
			}
		}

		if (failedEntities.length) {
			if (failedEntities.length > MAX_FAILED_SYNC_ENTITIES) {
				message = `The threshold for maximum failed synchronization entities has been met; further`
					+ ` processing of remaining entities has been aborted`;
			} else {
				message = `1 or more entities failed to synchronize`
			}
		}

		if (successfulEntities.length > MAX_SUCCESSFUL_SYNC_ENTITIES) {
			message = `The threshold for maximum successful synchronization entities has been met; further`
				+ ` processing of remaining entities has been aborted`;
		}
		const resultPayload = {
			data: {
				failed_count: failedEntities.length,
				failed_entities: failedEntities,
				failed_threshold_met: failedEntities.length >= MAX_FAILED_SYNC_ENTITIES,
				successful_count: successfulEntities.length,
				successful_entities: successfulEntities,
				successful_threshold_met: successfulEntities.length >= MAX_SUCCESSFUL_SYNC_ENTITIES,
			},
			message,
			status: failedEntities.length
				? HttpStatus.CONFLICT
				: HttpStatus.OK,
		}
		logObj.attachment = { resultPayload, message: 'Sync catalog response' };
		logger.info(LogEvent.serviceResponse, logObj);
		// Return the synchronization result payload.
		return resultPayload;
	} catch (error) {
		logObj.attachment = { error, message: 'Error occurred while syncing entity' };
		logger.error(LogEvent.serviceResponse, logObj);
		if (error instanceof HttpException) {
			throw error
		} else {
			throw new InternalServerErrorException(
				'An error occurred while synchronizing catalog entities',
				{ cause: error },
			);
		}
	}
}


/**
 * -----------------------------------------------------------------------------
 * Updates an entity's `_metadata` map, ensuring its existence and updating its
 * respective key values with some of the data provided.
 * -----------------------------------------------------------------------------
 * @param entity        - The entity object whose metadata map is to be updated.
 * @param productType   - The catalog name of the entity.
 * @param productId     - The entity id.
 * @param productStatus - The `draft` or `published` state of the entity.
 * @returns             - The original entity, with its `_metadata` map updated.
 * -----------------------------------------------------------------------------
 */
function updateEntityMetadata(
	entity: Record<string, any>,
	productType: string,
	productId: string,
	productStatus: 'draft' | 'published',
): Record<string, any> {
	// Ensure the `_metadata` key exists in the entity.
	entity._metadata = entity._metadata
		? entity._metadata
		: {
			lastSyncedTime: new Date().toISOString(),
			productId,
			productStatus,
			productType,
		};

	// Update the  metadata.
	entity._metadata['isViewable'] = true
	entity._metadata['productSource'] = "MPM"
	entity._metadata['isPublished'] = false

	// Update the product data.
	for (const [key, value] of Object.entries({ productId, productStatus, productType })) {
		if (
			(!(key in entity._metadata))
			|| (!value)
		) {
			entity._metadata[key] = value;
		}
	}
	return entity;
}


// Export the interface.
export {
	Catalog,
	getDataFromEventRequest,
	syncCatalogEntities,
	updateEntityMetadata,
};
