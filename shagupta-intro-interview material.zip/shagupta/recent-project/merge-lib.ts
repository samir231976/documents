/**
 * =============================================================================
 * @file Merge library.
 * @desc This file provides utilitarian functionality for JSON object merging-based
 * functionality.
 * =============================================================================
 */


// Import the dependencies.
import { mergeAdvanced as merge } from 'object-merge-advanced';

/**
 * -----------------------------------------------------------------------------
 * GET/SET value of Object attribute based provided path/level
 * -----------------------------------------------------------------------------
 * @param entityReference - JSON object to travels.
 * @param path            - Absolute path of JSON object attribute.
 * @param value           - Value to be updated to JSON object attribute.
 * @returns {string}      - Get/Set value of JSON object attribute
 * -----------------------------------------------------------------------------
 */

function nodeIndex(
    entityReference: any,
    nodePath: any,
    value: any = undefined
) {
    if (entityReference !== null) {
        if (typeof nodePath == 'string')
            return nodeIndex(entityReference, nodePath.split('.'), value);
        else if (nodePath.length == 1 && value !== undefined)
            return entityReference[nodePath[0]] = value;
        else if (nodePath.length == 0)
            return entityReference;
        else
            return nodeIndex(entityReference[nodePath[0]], nodePath.slice(1), value);
    }
    return entityReference;
}

/**
 * -----------------------------------------------------------------------------
 * Update Second object attribute, if crashing key has _source field value
 * -----------------------------------------------------------------------------
 * @param inputArg1 - It’s the value of the key that’s clashing; comes from first main input argument 
 * @param inputArg2 - It’s the value of the key that’s clashing; comes from second main input argument
 *                    [right now not in use but still keeping for future reference, as its past of callback function of library]
 * @param resultAboutToBeReturned - Algorithm already decided what the result would normally be, if you were not using the callback. It’s that result here.
 * @param infoObj   - This plain object contains the location info about the keys: key names and full paths, plus, the type of the parent (array or object).
 * @param entityReference  - JSON object of Second main input argument of merge function
 * -----------------------------------------------------------------------------
 */
function mergeSourceAttribute(
    inputArg1: any,
    inputArg2: any,
    resultAboutToBeReturned: any,
    infoObj: any,
    entityReference: any
) {
    let value = nodeIndex(entityReference, `${infoObj?.path}_source`);
    if (value !== undefined) {
        nodeIndex(entityReference, `${infoObj?.path}_source`, inputArg1);
    }
    else {
        let valueNoSource = nodeIndex(entityReference, `${infoObj?.path}`);
        if (typeof valueNoSource !== 'object' && valueNoSource !== undefined) {
            nodeIndex(entityReference, `${infoObj?.path}`, inputArg1);
        }
    }
    return resultAboutToBeReturned;
}

function mergeCustomAttribute(
    entityReference1: any,
    entityReference2: any,
    mergeOptions: any
) {
    const initialLevelMergeRes = merge(
        entityReference1,
        entityReference2,
        {
            cb: (inputArg1, inputArg2, resultAboutToBeReturned, infoObj) => {
                // Update Second object if crashing key has _source field value
                mergeSourceAttribute(inputArg1, inputArg2, resultAboutToBeReturned, infoObj, entityReference2);
                // whatever you return here gets written as the value of clashing keys:
                return resultAboutToBeReturned;
            },
        },
    );
    const finalLevelMergeRes = merge(
        entityReference1,
        entityReference2,
        mergeOptions
    );
    return finalLevelMergeRes;
}

export { mergeCustomAttribute }
