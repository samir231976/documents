var express = require('express');
var app = express();
const fs = require('fs');
const mysql = require('mysql');
var ip = require("ip");
var dbConnection = false;
var dbErr='';
var os = require('os');
 var networkInterfaces = os. networkInterfaces();
console.log(networkInterfaces);
var server_ip=networkInterfaces;
var records='';

var connection = mysql.createConnection({
    host: 'd3ploy.mysql.database.azure.com',
    user: 'deployroot',
    password: 'Welcome@123',
    database: 'deploydb',
        ssl: {
        ca: ''//fs.readFileSync(__dirname + '/DigiCertGlobalRootCA.crt.pem'),
    }
});

connection.connect(function (err) {
   if(err){
    dbConnection= false;
    dbErr=err;
       console.log("error occurred while connecting",err);
   }
   else{
       dbConnection= true;
       console.log("connection created with Mysql successfully");
            // if connection is successful
          connection.query("SELECT * FROM project", function (err, result, fields) {
         // if any error while executing above query, throw error
           if (err) throw err;
          // if there is no error, you have the result
              console.log(result);
                  records=result;
           });


   }
});


app.get('/', function (req, res) {
    console.log(dbConnection);
    res.send('{ "response": "Hello From Thetips4you1" }');
});
app.get('/conn', function (req, res) {
    console.log(dbConnection);
    if(dbConnection){

         res.send({"response":records})
    }
    else{
         res.send({ "response": dbErr+"Mysql connection failled"+"  Node Ip address "+ip.address()+" Server IP: "+server_ip });
         //   res.send({"response": dbErr+"Mysql connection failled"});
    }
});

app.get('/will', function (req, res) {
    res.send('{ "response": "Hello World" }');
});
app.get('/ready', function (req, res) {
    res.send('{ "response": " Great!, It works!", }');
});
app.listen(process.env.PORT || 3000);
module.exports = app;
